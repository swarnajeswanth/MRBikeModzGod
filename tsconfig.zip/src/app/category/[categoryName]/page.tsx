import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CategoryClient from "@/components/CategoryClient";

interface PageProps {
  params: {
    categoryName: string;
  };
}

// ✅ Server component
export default function CategoryPage({ params }: PageProps) {
  return (
    <>
      <Header />
      <CategoryClient categoryName={params.categoryName} />
      <Footer />
    </>
  );
}
